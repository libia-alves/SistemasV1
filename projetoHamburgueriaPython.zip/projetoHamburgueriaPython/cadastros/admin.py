from django.contrib import admin

# Register your models here.

from .models import Pratos, Atividade

admin.site.register(Pratos)
admin.site.register(Atividade)

